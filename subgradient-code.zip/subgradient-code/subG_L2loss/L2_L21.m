%%  **************************************************************
%%  Phi_{lam,nu}(U,V)= 0.5*||UV'-b||_F^2  + lambda*(||U||_2,1+ ||V||_2,1) + nu*||UV'||_TV }
%
%% *************************************************************

function [fval,gradPhiU,gradPhiV] = L2_L21(X,U,V,b,Omega,lambda,nu,n,nr)

Ut = zeros(n,nr); Vt = zeros(n,nr);

Ucnorm = dot(U,U).^(1/2);   Vcnorm = dot(V,V).^(1/2);

pUidx = find(Ucnorm/max(Ucnorm)>1e-6);    

pVidx = find(Vcnorm/max(Vcnorm)>1e-6);

pidx = intersect(pUidx,pVidx);

if isempty(pidx)
    
    mg = 'lambda is too large';
    
    return;    
else
    
    Ut(:,pidx) = U(:,pidx)./Ucnorm(pidx);
    
    Vt(:,pidx) = V(:,pidx)./Ucnorm(pidx);
end

UVb = Omega.*(X-b);

DX = Dmap(X);

fval = 0.5*norm(UVb,'fro')^2 + lambda*sum(Ucnorm+Vcnorm) + nu*norm(DX(:),1);

nuDtX = nu*Dtmap(sign(DX),n);

temp_mat = UVb + nuDtX;

gradPhiU = temp_mat*V + lambda*Ut;

gradPhiV = temp_mat'*U + lambda*Vt;

end

%%  **************************************************************
%%  Phi_{lam,nu}(U,V)= 0.5*||UV'-b||_F^2  + lambda*(scad(||U_j||)+scad(||Vj||)) + nu*||UV'||_TV }
%
%% *************************************************************

function [fval,gradPhiU,gradPhiV] = L2_scad(X,U,V,b,Omega,lambda,nu,acon,rho,n,nr)

Ut = zeros(n,nr); Vt = zeros(n,nr);

arho = 0.5*(acon+1)*rho;

acon1 = acon/(acon-1);

acon2 = arho/(acon-1);

Ucnorm = dot(U,U).^(1/2);

Vcnorm = dot(V,V).^(1/2);

pUidx = find(Ucnorm/max(Ucnorm)>1e-6);    

pVidx = find(Vcnorm/max(Vcnorm)>1e-6);

pidx = intersect(pUidx,pVidx);

if isempty(pidx)
    
    mg = 'lambda is too large';
    
    return;    
else
    
    Ut(:,pidx) = U(:,pidx)./Ucnorm(pidx);
    
    Vt(:,pidx) = V(:,pidx)./Ucnorm(pidx);
end

UVb = Omega.*(X-b);

DX = Dmap(X);

cscad = sum(Ucnorm+Vcnorm) -(1/rho)*(scad(rho*Ucnorm,acon)+scad(rho*Vcnorm,acon));

fval = 0.5*norm(UVb,'fro')^2  + lambda*cscad + nu*norm(DX(:),1);

nuDtX = nu*Dtmap(sign(DX),n);

temp_gradU = lambda*max(0,min(1,acon1-acon2*Ucnorm));

temp_gradV = lambda*max(0,min(1,acon1-acon2*Vcnorm));

temp_mat = UVb+nuDtX;

gradPhiU = temp_mat*V + temp_gradU.*Ut;

gradPhiV = temp_mat'*U + temp_gradV.*Vt;

end

function fval = scad(u,acon)

acon1 = 2/(acon+1);

acon2 = acon1*acon;

tempu1 = u(u>acon1 & u<=acon2);

u1 = ((acon+1)*tempu1-2).^2/(4*(acon^2-1));

fval = sum(u(u>acon2)-1) + sum(u1);

end


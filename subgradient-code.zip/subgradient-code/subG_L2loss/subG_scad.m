function [X,obj_list] = subG_scad(b,Omega,Mstar,r,lambda,nu,acon,OPTIONS)

if isfield(OPTIONS,'tol');        tol       = OPTIONS.tol;           end
if isfield(OPTIONS,'printyes');   printyes  = OPTIONS.printyes;      end
if isfield(OPTIONS,'maxiter');    maxiter   = OPTIONS.maxiter;       end

[m,n] = size(b);

r = min(min(m,n),r);

normb = norm(b,'fro');

[U1,dA,V1] = svd(b,'econ');

temp_dA = diag(dA);

temp_dA = temp_dA(1:r).^(1/2);

U = 0.05*U1(:,1:r).*temp_dA'; V = 0.05*V1(:,1:r).*temp_dA';

fprintf('\n *****************************************************');
fprintf('******************************************');
fprintf('\n **************  subG_scad  for solving low-rank recovery  problems  ********************');
fprintf('\n ****************************************************');
fprintf('*******************************************');
fprintf('\n  iter     relerr       obj_diff      step-size     psnr     time');

%% ***************** Initialization **************************

obj_list =zeros(maxiter,1);

tstart = clock;

rho = 1.0;

X = b;    %U*V';

[~,subgPhiU,subgPhiV] = L2_scad(X,U,V,b,Omega,lambda,nu,acon,rho,n,r);

%% ************************* Main Loop *********************************

for iter = 1:maxiter
    
    %% **** choose step size *************************
    
    mu = iter^(-0.05)*(0.2/normb);
    
    %% ************* compute (Unew,Vnew) ***************
    
    U = U - mu*subgPhiU;
    
    V = V - mu*subgPhiV;
    
    X = U*V';
    
    ttime = etime(clock,tstart);
    
    [obj,subgPhiU,subgPhiV] = L2_scad(X,U,V,b,Omega,lambda,nu,acon,rho,n,r);
    
    obj_list(iter) = obj;
    
    if  printyes && mod(iter,500)==0
        
        psnr1 = psnr(X,Mstar,255);
        
        obj_diff = max(abs(obj-obj_list(iter-99:iter)))/max(1,obj);
        
        relerr = norm(X - Mstar,'fro')/norm(Mstar,'fro');
        
        fprintf('\n  %2d    %3.4e   %3.4e    %3.2e     %5.4e    %3.2f ',iter,relerr,obj_diff,mu,psnr1,ttime);
    end
    
    %% *************** check the stopping criterion *******************
   
    if iter>100 && max(abs(obj-obj_list(iter-99:iter)))/max(1,obj)<=tol
        
        return;
    end
    
end

end


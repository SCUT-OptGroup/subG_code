function [X,obj_list] = subG_TV(b,Omega,Mstar,r,nu,OPTIONS)

if isfield(OPTIONS,'tol');        tol       = OPTIONS.tol;           end
if isfield(OPTIONS,'printyes');   printyes  = OPTIONS.printyes;      end
if isfield(OPTIONS,'maxiter');    maxiter   = OPTIONS.maxiter;       end

[m,n] = size(b);

r = min(min(m,n),r);

normb = norm(b,'fro');

[U1,dA,V1] = svd(b,'econ');

temp_dA = diag(dA);

temp_dA = temp_dA(1:r).^(1/2);

U = 0.05*U1(:,1:r).*temp_dA'; V =0.05*V1(:,1:r).*temp_dA';

if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n **************  subG_TV  for solving low-rank recovery  problems  ********************');
    fprintf('\n ****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter     relerr       obj_diff      step-size     psnr     time');
    
end
%% ***************** Initialization **************************

obj_list = zeros(maxiter,1);

tstart = clock;

X = b; %U*V';

UVb = Omega.*(X-b);

DX = Dmap(X);

temp_mat = UVb + nu*Dtmap(sign(DX),n);

subgPhiU = temp_mat*V; subgPhiV = temp_mat'*U;

%% ************************* Main Loop *********************************

for iter = 1:maxiter
    
    %% **** choose step size *************************
    
    mu = iter^(-0.05)*(0.2/normb);
    
    %% ************* compute (Unew,Vnew) ***************
    
    U = U - mu*subgPhiU;
    
    V = V - mu*subgPhiV;
    
    X = U*V';
    
    UVb = Omega.*(X-b);
    
    DX = Dmap(X);
    
    obj = 0.5*norm(UVb,'fro')^2 + nu*norm(DX(:),1);
    
    obj_list(iter) = obj;
    
    %% ********************** Optimality checking  *****************************************************************
    
    ttime = etime(clock,tstart);
    
    if printyes && mod(iter,500)==0
        
        psnr1 = psnr(X,Mstar,255);
        
        obj_diff = max(abs(obj-obj_list(iter-99:iter)))/max(1,obj);
        
        relerr = norm(X - Mstar,'fro')/norm(Mstar,'fro');
        
        fprintf('\n  %2d    %3.4e   %3.4e    %3.2e     %5.4e    %3.2f ',iter,relerr,obj_diff,mu,psnr1,ttime);
    end
    
    %% *************** check the stopping criterion *******************
    
    if iter>100 && max(abs(obj-obj_list(iter-99:iter)))/max(1,obj)<=tol
        
        return;
        
    end
    
    temp_mat = UVb + nu*Dtmap(sign(DX),n);
    
    subgPhiU = temp_mat*V; subgPhiV = temp_mat'*U;
    
end

end
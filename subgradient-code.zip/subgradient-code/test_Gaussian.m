%% *************** Demo_impluse ***********************************

clear;

close all;
restoredefaultpath;
addpath(genpath('subG_L2loss'));

%% for experiment use
pic_list = {'Autumn.jpg','Desert.jpg','Forest.jpg','Sea.jpg','Starfish.jpg','Sunrise.jpg','Wheat.jpg','Apartment.jpg'};

picgaussian_list = {'Autumn.mat','Desert.mat','Forest.mat','Sea.mat','Starfish.mat','Sunrise.mat','Wheat.mat','Apartment.mat'};

p_data = 'PLZ enter a number between 1-12 for read a color image: ';
imagenum = input(p_data);
pic_name = pic_list{imagenum};
gaussian_image = picgaussian_list{imagenum};

% read original image
cd pic
Xfulld = double(imread(pic_name));
cd ..

% read image with Gaussian noise
cd GaussianPic
load(gaussian_image);
cd ..


sizem = size(Xfull,1);
sizen = size(Xfull,2);

% Add Masks
p_mask = 'PLZ enter a number between 1-3 for read a mask: ';
n_mask = input(p_mask);

switch n_mask
    case 1
        % Text Noise
        T = double(imread('Text_noise.bmp'));
        mask(:,:,1) = T; mask(:,:,2) = T; mask(:,:,3) = T;     
    case 2
        % Random Noise
        rng(5,'twister');
        ind = randi(10,sizem,sizen); 
        oldind = ind;
        kk = 4;
        ind = (oldind < kk);   % 60% entries are missing, controlled by kk.
        mask(:,:,1) = ind; mask(:,:,2) = ind; mask(:,:,3) = ind;
       
    case 3
        % Block Noise
        I_Omega = double(imread('OMEGA_9.bmp')); % missing image
        mask(:,:,1) = I_Omega; mask(:,:,2) = I_Omega; mask(:,:,3) = I_Omega;
    
    otherwise
        warning('Unexpected mask type.');
        return;
end

        
Xmiss = Xfull.*mask;
Amap1 = @(x) mask(:,:,1).*x;
Amap2 = @(x) mask(:,:,2).*x;
Amap3 = @(x) mask(:,:,3).*x;

tol = 1.0e-5;  maxIter = 10000;  rank_r = 100;

OPTIONS.printyes = 0;
OPTIONS.tol = tol;
OPTIONS.maxiter = maxIter; 

%% ******************** subG-L21 ***********************************

lambda = 500; nu = 6.0; 

tstart = clock;
[subG_recon_R] = subG_L1(Xmiss(:,:,1),mask(:,:,1),Xfulld(:,:,1),rank_r,lambda,nu,OPTIONS);
[subG_recon_G] = subG_L1(Xmiss(:,:,2),mask(:,:,2),Xfulld(:,:,2),rank_r,lambda,nu,OPTIONS);
[subG_recon_B] = subG_L1(Xmiss(:,:,3),mask(:,:,3),Xfulld(:,:,3),rank_r,lambda,nu,OPTIONS);
subG_image = cat(3,subG_recon_R,subG_recon_G,subG_recon_B);
subG_image = max(subG_image,0);
subG_image = min(subG_image,255);

time_subG = etime(clock,tstart)
psnr_subG = psnr(subG_image,Xfulld,255)
ssim_subG = ssim(subG_image,Xfulld,'DynamicRange',255)

%% ******************** subG-scad ***********************************

lambda = 500; nu = 6.0; acon=4;  

tstart = clock;
[subG_scad_recon_R] = subG_scad(Xmiss(:,:,1),mask(:,:,1),Xfulld(:,:,1),rank_r,lambda,nu,acon,OPTIONS);
[subG_scad_recon_G] = subG_scad(Xmiss(:,:,2),mask(:,:,2),Xfulld(:,:,2),rank_r,lambda,nu,acon,OPTIONS);
[subG_scad_recon_B] = subG_scad(Xmiss(:,:,3),mask(:,:,3),Xfulld(:,:,3),rank_r,lambda,nu,acon,OPTIONS);
subG_scad_image = cat(3,subG_scad_recon_R,subG_scad_recon_G,subG_scad_recon_B);
subG_scad_image = max(subG_scad_image,0);
subG_scad_image = min(subG_scad_image,255);

time_subG_scad= etime(clock,tstart)
psnr_subG_scad = psnr(subG_scad_image,Xfulld,255)
ssim_subG_scad = ssim(subG_scad_image,Xfulld,'DynamicRange',255)

%% ******************** subG-TV ***********************************

nu = 6.0; 

tstart = clock;
[subG_TV_recon_R] = subG_TV(Xmiss(:,:,1),mask(:,:,1),Xfulld(:,:,1),rank_r,nu,OPTIONS);
[subG_TV_recon_G] = subG_TV(Xmiss(:,:,2),mask(:,:,2),Xfulld(:,:,2),rank_r,nu,OPTIONS);
[subG_TV_recon_B] = subG_TV(Xmiss(:,:,3),mask(:,:,3),Xfulld(:,:,3),rank_r,nu,OPTIONS);
subG_TV_image = cat(3,subG_TV_recon_R,subG_TV_recon_G,subG_TV_recon_B);
subG_TV_image = max(subG_TV_image,0);
subG_TV_image = min(subG_TV_image,255);

time_subG_TV = etime(clock,tstart)
psnr_subG_TV = psnr(subG_TV_image,Xfulld,255)
ssim_subG_TV = ssim(subG_TV_image,Xfulld,'DynamicRange',255)

%% Experimental results
noisy_ssim = ssim(Xmiss,Xfulld,'DynamicRange',255)
noisy_psnr = psnr(Xmiss,Xfulld,255)

figure; imshow(Xfull/255,[]); title('Original image','FontSize',15,'FontName','Times New Roman'); 
figure; imshow(Xmiss/255,[]); title('Masked image','FontSize',15,'FontName','Times New Roman'); 
figure; imshow(subG_image/255,[]); title('Recovered image by subG-L21','FontSize',15,'FontName','Times New Roman'); 
figure; imshow(subG_scad_image/255,[]); title('Recovered image by subG-SCAD','FontSize',15,'FontName','Times New Roman'); 
figure; imshow(subG_TV_image/255,[]); title('Recovered image by subGTV','FontSize',15,'FontName','Times New Roman'); 




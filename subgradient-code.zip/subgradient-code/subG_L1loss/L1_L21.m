%%  **************************************************************
%%  Phi_{lam,nu}(U,V)= ||P_{Omega}(UV'-b)||_1  + lambda*(||U||_2,1+ ||V||_2,1) + nu*||UV'||_TV }
%
%% *************************************************************
function [fval,gradPhiU,gradPhiV] = L1_L21(X,U,V,b,Omega,lambda,nu,n,nr)

Ut = zeros(n,nr); Vt = zeros(n,nr);

Ucnorm = dot(U,U).^(1/2);   Vcnorm = dot(V,V).^(1/2);
    
pUidx = find(Ucnorm/max(Ucnorm)>1e-6);    

pVidx = find(Vcnorm/max(Vcnorm)>1e-6);

pidx = intersect(pUidx,pVidx);

if isempty(pidx)
    
    mg = 'lambda is too large';
    
    return;    
else
    
    Ut(:,pidx) = U(:,pidx)./Ucnorm(pidx);
    
    Vt(:,pidx) = V(:,pidx)./Ucnorm(pidx);
end

UVb = Omega.*(X-b);

DX = Dmap(X);

fval = norm(UVb(:),1) + lambda*sum(Ucnorm+Vcnorm) + nu*norm(DX(:),1);

nuDtX = nu*Dtmap(sign(DX),n);

temp_mat = sign(UVb) + nuDtX;

gradPhiU = temp_mat*V + lambda*Ut;

gradPhiV = temp_mat'*U + lambda*Vt;

end
